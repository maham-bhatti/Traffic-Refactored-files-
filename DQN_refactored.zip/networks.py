"""
networks.py
===========
Neural network and buffer building blocks for MA DQN:
  - DeepQNetwork  2-hidden-layer (64->128) Q-function approximator
  - ReplayBuffer  fixed-capacity experience replay buffer

Kept separate from ma_dqn.py so the model/buffer definitions are easy
to find independently of the agent/controller orchestration logic.
"""

import random

import numpy as np
import torch
import torch.nn as nn
from collections import deque


# ─────────────────────────────────────────────────────────────────────────────
#  DEEP Q-NETWORK  (3 layers — deep, unlike linear Q-learning)
# ─────────────────────────────────────────────────────────────────────────────

class DeepQNetwork(nn.Module):
    """
    Q(s, a) with 2 hidden layers.
    Matches MAPPO Actor depth for fair architectural comparison.

    Architecture: obs_dim → 64 → ReLU → 128 → ReLU → action_dim
    Output: Q-values for all actions, shape (action_dim,).

    The depth is intentionally the same as the MAPPO Actor so that any
    performance difference comes from the RL algorithm (policy-based vs
    value-based), not from network capacity.
    """
    def __init__(self, obs_dim: int, action_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim,  64),  nn.ReLU(),
            nn.Linear(64,      128),  nn.ReLU(),
            nn.Linear(128, action_dim),
        )
        nn.init.orthogonal_(self.net[-1].weight, gain=1.0)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        return self.net(obs)


# ─────────────────────────────────────────────────────────────────────────────
#  REPLAY BUFFER
# ─────────────────────────────────────────────────────────────────────────────

class ReplayBuffer:
    """
    Experience replay buffer.
    Stores (obs, action, reward, next_obs, done) tuples.
    Sampling breaks temporal correlations → stabler gradient updates.
    """
    def __init__(self, capacity: int, obs_dim: int):
        self.capacity = capacity
        self.obs_dim  = obs_dim
        self.buffer   = deque(maxlen=capacity)

    def push(self, obs: np.ndarray, action: int, reward: float,
             next_obs: np.ndarray, done: bool):
        self.buffer.append((obs, action, reward, next_obs, float(done)))

    def sample(self, batch_size: int, device: torch.device):
        batch = random.sample(self.buffer, batch_size)
        obs, acts, rews, next_obs, dones = zip(*batch)
        return (
            torch.FloatTensor(np.array(obs)).to(device),
            torch.LongTensor(acts).to(device),
            torch.FloatTensor(rews).to(device),
            torch.FloatTensor(np.array(next_obs)).to(device),
            torch.FloatTensor(dones).to(device),
        )

    def __len__(self):
        return len(self.buffer)

    def ready(self, batch_size: int) -> bool:
        return len(self.buffer) >= batch_size
