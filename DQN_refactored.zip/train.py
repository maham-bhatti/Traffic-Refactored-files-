"""
train.py
========
GCN + Multi-Agent DQN training loop, curriculum schedule, evaluation,
and CLI entry point.

The environment (SUMOEnv) lives in traci_env.py; this module wires it
together with MADQNController and drives episodes.

Key differences from the MAPPO project's train.py:
  - No rollout buffer: update() called every step (but internally DQN
    only trains once replay buffer has >= BATCH_SIZE transitions).
  - ctrl.update() takes (raw_obs, rewards, done) — pushes to replay buffer
    and samples a mini-batch if buffer is ready.
  - ctrl.decay_epsilon() called once per episode after env.close().
  - Logging includes dqn_loss, epsilon, and replay buffer size.
  - Target network copied every TARGET_UPDATE steps (handled inside MADQNAgent).
"""

import os
import time
from collections import defaultdict

import numpy as np

from junction_config import REAL_JUNCTIONS
from ma_dqn import MADQNController, MAX_EPISODES
from traci_env import SUMOEnv, WARMUP_STEPS, EP_DURATION


# ══════════════════════════════════════════════════════════════════════════════
#  EPISODE ROLLOUT  (shared by training and evaluation)
# ══════════════════════════════════════════════════════════════════════════════

def _run_episode(ctrl: MADQNController, env: SUMOEnv, learn: bool):
    """
    Run one full episode against `env` using `ctrl`.

    If learn=True: pushes transitions to the replay buffer and trains via
    ctrl.update() every step (no-op internally until the buffer is ready),
    tracking per-step DQN loss. If learn=False (evaluation): just acts,
    no updates.

    Returns: (ep_rew: dict, avg_tt: float, step_n: int, avg_loss: float)
    """
    raw_obs = env.reset()
    ep_rew  = defaultdict(float)
    done    = False
    step_n  = 0
    ep_loss = []

    while not done:
        actions = ctrl.act(raw_obs)
        raw_obs, rews, done, info = env.step(actions)
        if learn:
            log = ctrl.update(raw_obs, rews, done)
            ep_loss.append(log["dqn_loss"])
        for jid in REAL_JUNCTIONS:
            ep_rew[jid] += rews.get(jid, 0.0)
        step_n += 1

    avg_tt   = env.avg_tt()
    avg_loss = float(np.mean(ep_loss)) if ep_loss else 0.0
    return ep_rew, avg_tt, step_n, avg_loss


# ══════════════════════════════════════════════════════════════════════════════
#  CURRICULUM
# ══════════════════════════════════════════════════════════════════════════════

def _get_density_for_episode(ep: int, n_episodes: int) -> str:
    """
    Curriculum schedule:
      Stage 1 (first 25%):  low
      Stage 2 (next 25%):   medium
      Stage 3 (last 50%):   high
    """
    frac = ep / n_episodes
    if frac < 0.25:
        return "low"
    elif frac < 0.50:
        return "medium"
    else:
        return "high"


# ══════════════════════════════════════════════════════════════════════════════
#  TRAINING LOOP
# ══════════════════════════════════════════════════════════════════════════════

def train(n_episodes: int = MAX_EPISODES,
          device:     str = "cpu",
          save_dir:   str = "ckpt_dqn",
          resume_from: str = None,
          use_gui:    bool = False,
          curriculum: bool = False,
          density:    str = None):
    """
    GCN + Multi-Agent DQN training loop.

    Key differences from MAPPO training loop:
      - No rollout buffer: update() called every step (but internally DQN
        only trains once replay buffer has >= BATCH_SIZE transitions).
      - ctrl.update() takes (raw_obs, rewards, done) — pushes to replay buffer
        and samples a mini-batch if buffer is ready.
      - ctrl.decay_epsilon() called once per episode after env.close().
      - Logging includes dqn_loss, epsilon, and replay buffer size.
      - Target network copied every TARGET_UPDATE steps (handled inside MADQNAgent).

    Episode structure (same as MAPPO for fair comparison):
      900s  warm-up  — SUMO fixed-time plan, no agent
      2700s training — agent controls, DQN updated from replay buffer every step
      Total: 3600s per episode
    """
    print("=" * 70)
    print(f"  GCN-MA-DQN Training  |  device={device}  |  episodes={n_episodes}")
    print("  Algorithm  : DQN — deep Q-network + replay buffer + target network")
    print("  Reward     : -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait)")
    print("  Update     : Batch TD, replay buffer per agent, target network")
    print(f"  Curriculum : {'ON' if curriculum else 'OFF'}")
    print("=" * 70)

    ctrl = MADQNController(device=device)
    if resume_from:
        ctrl.load(resume_from)

    best_tt = float("inf")
    ep_log  = []

    for ep in range(1, n_episodes + 1):
        ep_density = _get_density_for_episode(ep, n_episodes) if curriculum else density
        env        = SUMOEnv(use_gui=use_gui, density=ep_density)

        t0 = time.time()
        ep_rew, avg_tt, step_n, avg_loss = _run_episode(ctrl, env, learn=True)
        env.close()
        ctrl.decay_epsilon()   # epsilon decay once per episode

        avg_rew  = float(np.mean(list(ep_rew.values())))
        # Report replay buffer size of one representative agent
        buf_size = len(ctrl.agents[REAL_JUNCTIONS[0]].replay)

        ep_log.append({
            "ep":          ep,
            "avg_rew":     avg_rew,
            "avg_tt":      avg_tt,
            "avg_loss":    avg_loss,
            "epsilon":     ctrl.epsilon[0],
            "buffer_size": buf_size,
            "density":     ep_density or "default",
        })

        dens_tag = f"[{ep_density or 'default':7s}]"
        print(f"  Ep {ep:4d}/{n_episodes} {dens_tag} | "
              f"reward={avg_rew:7.4f} | tt={avg_tt:6.1f}s | "
              f"loss={avg_loss:.4f} | ε={ctrl.epsilon[0]:.3f} | "
              f"buf={buf_size:5d} | steps={step_n:5d} | t={time.time()-t0:.0f}s")

        if ep % 50 == 0:
            ctrl.save(save_dir)
        if avg_tt > 0 and avg_tt < best_tt:
            best_tt = avg_tt
            ctrl.save(save_dir + "_best")
            print(f"  ★  New best travel time: {best_tt:.1f}s")

    ctrl.save(save_dir + "_final")
    _save_log(ep_log, save_dir)
    print(f"\n  Training complete. Best avg travel time: {best_tt:.1f}s")
    return ctrl


def _evaluate(ctrl: MADQNController, n_reps: int = 5, use_gui: bool = False,
              density: str = None):
    """Run evaluation episodes — no parameter updates, epsilon forced to 0."""
    saved_eps = ctrl.epsilon[0]
    ctrl.epsilon[0] = 0.0   # pure greedy (argmax Q) during evaluation

    tt_l, r_l = [], []
    for _ in range(n_reps):
        env = SUMOEnv(use_gui=use_gui, density=density)
        ep_rew, avg_tt, _, _ = _run_episode(ctrl, env, learn=False)
        tt_l.append(avg_tt)
        r_l.append(float(np.mean(list(ep_rew.values()))))
        env.close()

    ctrl.epsilon[0] = saved_eps   # restore epsilon
    print(f"  Eval ({n_reps} reps): "
          f"travel_time = {np.mean(tt_l):.1f} ± {np.std(tt_l):.1f}s  |  "
          f"reward = {np.mean(r_l):.4f}")


def _save_log(log: list, directory: str):
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, "training_log.csv")
    with open(path, "w") as f:
        f.write("episode,avg_reward,avg_travel_time,avg_loss,epsilon,buffer_size,density\n")
        for r in log:
            f.write(f"{r['ep']},{r['avg_rew']:.4f},{r['avg_tt']:.2f},"
                    f"{r.get('avg_loss', 0.0):.6f},{r.get('epsilon', 0.0):.4f},"
                    f"{r.get('buffer_size', 0)},{r.get('density', 'default')}\n")
    print(f"  Log saved -> {path}")


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="GCN + Multi-Agent DQN Traffic Signal Training")
    p.add_argument("--episodes",   type=int,  default=MAX_EPISODES)
    p.add_argument("--device",     type=str,  default="cpu", choices=["cpu", "cuda"])
    p.add_argument("--save_dir",   type=str,  default="ckpt_dqn")
    p.add_argument("--resume",     type=str,  default=None)
    p.add_argument("--gui",        action="store_true")
    p.add_argument("--eval_only",  action="store_true")
    p.add_argument("--curriculum", action="store_true")
    p.add_argument("--density",    type=str,  default=None,
                   choices=["low", "medium", "high"])
    args = p.parse_args()

    if args.eval_only:
        ctrl = MADQNController(device=args.device)
        if args.resume:
            ctrl.load(args.resume)
        _evaluate(ctrl, n_reps=10, use_gui=args.gui, density=args.density)
    else:
        train(n_episodes  = args.episodes,
              device       = args.device,
              save_dir     = args.save_dir,
              resume_from  = args.resume,
              use_gui      = args.gui,
              curriculum   = args.curriculum,
              density      = args.density)
