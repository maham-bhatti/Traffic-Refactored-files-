"""
junction_config.py
===================
Static registry describing the Manhattan 4x4 traffic network's junctions,
lane counts, green phases, and road adjacency.

VERIFIED against actual manhattan.net.xml:
  - 12 TLS junctions, all T-junctions
  - GREEN_PHASES: only green SUMO phase indices (0 and 2)
  - ACT_DIM: 1 for 3-phase junctions, 2 for 4-phase junctions
  - Phase strings confirmed from tlLogic elements

Phase strings from manhattan.net.xml:
  n_0_1 (3ph): GGGGG | yyyyy | rrrrr
  n_0_2 (4ph): GGGrr | yyyrr | rrrGG | rrryy
  n_1_0 (4ph): GGGGGrr | yyyyyrr | rrrrrGG | rrrrryy
  n_1_1 (4ph): GGGrrrrrGGg | yyyrrrrryyy | rrrGGGGGrrr | rrryyyyyrrr
  n_1_2 (4ph): rrrrrGGgGGG | rrrrryyyyyy | GGGGGrrrrrr | yyyyyrrrrrr
  n_1_3 (4ph): GGGGGrr | yyyyyrr | rrrrrGG | rrrrryy
  n_2_0 (4ph): GGGrr | yyyrr | rrrGG | rrryy
  n_2_1 (4ph): GGGrrrr | yyyrrrr | rrrGGGG | rrryyyy
  n_2_2 (4ph): GGGGrrrr | yyyyrrrr | rrrrGGGG | rrrryyyy
  n_2_3 (3ph): GGGGG | yyyyy | rrrrr
  n_3_1 (4ph): GGGrr | yyyrr | rrrGG | rrryy
  n_3_2 (3ph): GGGGG | yyyyy | rrrrr
"""

# ─────────────────────────────────────────────────────────────────────────────
#  JUNCTION REGISTRY
# ─────────────────────────────────────────────────────────────────────────────

REAL_JUNCTIONS = [
    "n_0_1", "n_0_2",
    "n_1_0", "n_1_1", "n_1_2", "n_1_3",
    "n_2_0", "n_2_1", "n_2_2", "n_2_3",
    "n_3_1", "n_3_2",
]
JID2IDX = {jid: i for i, jid in enumerate(REAL_JUNCTIONS)}
N_NODES = len(REAL_JUNCTIONS)  # 12

# Actual incoming lane counts (verified from net.xml incLanes)
JUNCTION_LANES = {
    "n_0_1": 2,
    "n_0_2": 5,
    "n_1_0": 5,
    "n_1_1": 9,
    "n_1_2": 9,
    "n_1_3": 5,
    "n_2_0": 5,
    "n_2_1": 7,
    "n_2_2": 7,
    "n_2_3": 3,
    "n_3_1": 5,
    "n_3_2": 2,
}
MAX_LANES = max(JUNCTION_LANES.values())  # 9

# GREEN phase indices only — agent NEVER selects yellow or all-red
# 3-phase junctions: only Phase 0 (single movement)
# 4-phase junctions: Phase 0 (direction A) or Phase 2 (direction B)
GREEN_PHASES = {
    "n_0_1": [0],       # single movement
    "n_0_2": [0, 2],
    "n_1_0": [0, 2],
    "n_1_1": [0, 2],
    "n_1_2": [0, 2],
    "n_1_3": [0, 2],
    "n_2_0": [0, 2],
    "n_2_1": [0, 2],
    "n_2_2": [0, 2],
    "n_2_3": [0],       # single movement
    "n_3_1": [0, 2],
    "n_3_2": [0],       # single movement
}

# Action space size per junction (1 or 2 green choices)
ACT_DIM = {jid: len(GREEN_PHASES[jid]) for jid in REAL_JUNCTIONS}

# Raw observation dimension = lane counts + 1 (current action index)
RAW_OBS_DIM = {jid: JUNCTION_LANES[jid] + 1 for jid in REAL_JUNCTIONS}

# Undirected adjacency edges for GCN
ROAD_EDGES = [
    ("n_0_1", "n_0_2"),
    ("n_1_0", "n_1_1"), ("n_1_1", "n_1_2"), ("n_1_2", "n_1_3"),
    ("n_2_0", "n_2_1"), ("n_2_1", "n_2_2"), ("n_2_2", "n_2_3"),
    ("n_3_1", "n_3_2"),
    ("n_1_0", "n_2_0"),
    ("n_0_1", "n_1_1"), ("n_1_1", "n_2_1"), ("n_2_1", "n_3_1"),
    ("n_0_2", "n_1_2"), ("n_1_2", "n_2_2"), ("n_2_2", "n_3_2"),
    ("n_1_3", "n_2_3"),
]

GCN_OUT_DIM = 32
