"""
networks.py
===========
Neural network building blocks for MAPPO-ATSC:
  - Actor          decentralised policy pi(a | aug_obs_i)
  - CentralCritic   centralised V(global_state), shared across agents
  - RolloutBuffer   per-agent trajectory storage + GAE computation

Kept separate from mappo_atsc.py so the model definitions are easy to
find independently of the training/orchestration logic.
"""

import numpy as np
import torch
import torch.nn as nn
from torch.distributions import Categorical

GAMMA      = 0.99
GAE_LAMBDA = 0.95


# ─────────────────────────────────────────────────────────────────────────────
#  ACTOR
# ─────────────────────────────────────────────────────────────────────────────

class Actor(nn.Module):
    """
    Decentralised policy pi(a | aug_obs_i).
    Output logits shape: (ACT_DIM[jid],) = 1 or 2 green choices.
    """
    def __init__(self, obs_dim: int, action_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim,  64),  nn.ReLU(),
            nn.Linear(64,      128),  nn.ReLU(),
            nn.Linear(128, action_dim),
        )
        nn.init.orthogonal_(self.net[-1].weight, gain=0.01)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        return self.net(obs)

    def get_action(self, obs: torch.Tensor):
        dist = Categorical(logits=self.forward(obs))
        a    = dist.sample()
        return a, dist.log_prob(a), dist.entropy()

    def evaluate_actions(self, obs: torch.Tensor, actions: torch.Tensor):
        dist = Categorical(logits=self.forward(obs))
        return dist.log_prob(actions), dist.entropy()


# ─────────────────────────────────────────────────────────────────────────────
#  CENTRALIZED CRITIC
# ─────────────────────────────────────────────────────────────────────────────

class CentralCritic(nn.Module):
    """Centralised V(global_state) shared across all agents."""
    def __init__(self, global_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(global_dim, 128), nn.ReLU(),
            nn.Linear(128,        256), nn.ReLU(),
            nn.Linear(256,        256), nn.ReLU(),
            nn.Linear(256,          1),
        )
        nn.init.orthogonal_(self.net[-1].weight, gain=1.0)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, gs: torch.Tensor) -> torch.Tensor:
        return self.net(gs)


# ─────────────────────────────────────────────────────────────────────────────
#  ROLLOUT BUFFER
# ─────────────────────────────────────────────────────────────────────────────

class RolloutBuffer:
    def __init__(self):
        self.clear()

    def clear(self):
        self.aug_obs   = []
        self.global_st = []
        self.actions   = []
        self.log_probs = []
        self.rewards   = []
        self.values    = []
        self.dones     = []

    def push(self, aug_obs, gs, action, lp, reward, value, done):
        self.aug_obs.append(aug_obs)
        self.global_st.append(gs)
        self.actions.append(int(action))
        self.log_probs.append(float(lp))
        self.rewards.append(float(reward))
        self.values.append(float(value))
        self.dones.append(float(done))

    def __len__(self):
        return len(self.rewards)

    def compute_gae(self, last_value: float):
        """Generalised Advantage Estimation (Schulman et al. 2016)."""
        T    = len(self.rewards)
        rew  = np.array(self.rewards,  np.float32)
        vals = np.array(self.values,   np.float32)
        done = np.array(self.dones,    np.float32)
        adv  = np.zeros(T,             np.float32)
        gae  = 0.0
        for t in reversed(range(T)):
            nv    = last_value if t == T - 1 else vals[t + 1]
            nd    = 0.0        if t == T - 1 else done[t + 1]
            delta = rew[t] + GAMMA * nv * (1 - nd) - vals[t]
            gae   = delta + GAMMA * GAE_LAMBDA * (1 - nd) * gae
            adv[t] = gae
        returns = adv + vals
        return torch.FloatTensor(adv), torch.FloatTensor(returns)

    def to_tensors(self):
        return (
            torch.FloatTensor(np.array(self.aug_obs)),
            torch.FloatTensor(np.array(self.global_st)),
            torch.LongTensor(self.actions),
            torch.FloatTensor(self.log_probs),
        )
