"""
train.py
========
GCN-MAPPO training loop, curriculum schedule, evaluation, and CLI entry point.

The environment (SUMOEnv) lives in traci_env.py; this module wires it
together with MAPPOController and drives episodes.
"""

import os
import time
from collections import defaultdict

import numpy as np

from junction_config import REAL_JUNCTIONS
from mappo_atsc import MAPPOController, ROLLOUT_LEN, MAX_EPISODES
from traci_env import SUMOEnv, WARMUP_STEPS, EP_DURATION


# ══════════════════════════════════════════════════════════════════════════════
#  EPISODE ROLLOUT  (shared by training and evaluation)
# ══════════════════════════════════════════════════════════════════════════════

def _run_episode(ctrl: MAPPOController, env: SUMOEnv,
                  learn: bool, rollout_n: int = 0):
    """
    Run one full episode against `env` using `ctrl`.

    If learn=True: stores transitions and triggers ctrl.update() every
    ROLLOUT_LEN steps (or on episode end), advancing the rollout step
    counter across episode boundaries exactly as the original training
    loop did. If learn=False (evaluation): just acts, no storage/updates.

    Returns: (ep_rew: dict, avg_tt: float, step_n: int, rollout_n: int)
    """
    raw_obs = env.reset()
    ep_rew  = defaultdict(float)
    done    = False
    step_n  = 0

    while not done:
        acts, lps, vals, aug, gs = ctrl.act(raw_obs)
        raw_obs, rews, done, info = env.step(acts)
        if learn:
            ctrl.store(aug, gs, acts, lps, rews, vals, done)
        for jid in REAL_JUNCTIONS:
            ep_rew[jid] += rews.get(jid, 0.0)
        step_n += 1
        if learn:
            rollout_n += 1
            if rollout_n >= ROLLOUT_LEN or done:
                ctrl.update(raw_obs)
                rollout_n = 0

    avg_tt = env.avg_tt()
    return ep_rew, avg_tt, step_n, rollout_n


# ══════════════════════════════════════════════════════════════════════════════
#  CURRICULUM
# ══════════════════════════════════════════════════════════════════════════════

def _get_density_for_episode(ep: int, n_episodes: int) -> str:
    """
    Curriculum schedule:
      Stage 1 (first 25%):  low     — off-peak   ~824  veh/hr
      Stage 2 (next 25%):   medium  — mid-day    ~1685 veh/hr
      Stage 3 (last 50%):   high    — peak-hour  ~3376 veh/hr
    """
    frac = ep / n_episodes
    if frac < 0.25:
        return "low"
    elif frac < 0.50:
        return "medium"
    else:
        return "high"


# ══════════════════════════════════════════════════════════════════════════════
#  TRAINING LOOP
# ══════════════════════════════════════════════════════════════════════════════

def train(n_episodes: int = MAX_EPISODES,
          device:     str = "cpu",
          save_dir:   str = "ckpt_mappo",
          resume_from: str = None,
          use_gui:    bool = False,
          curriculum: bool = False,
          density:    str = None):
    """
    Full GCN-MAPPO training loop.

    Episode structure  (matches Gridnetwork.py SIM_DURATION = 3600s):
      15 min (900s)  warm-up  — SUMO default fixed-time plan, no agent
      45 min (2700s) learning — agent controls, MAPPO updates every ROLLOUT_LEN steps
      Total: 3600s = 1 hour per episode

    Curriculum mode (--curriculum flag):
      Episodes 1–25%:   low density    (off-peak,   ~824  veh/hr)
      Episodes 25–50%:  medium density (mid-day,    ~1685 veh/hr)
      Episodes 50–100%: high density   (peak-hour,  ~3376 veh/hr)
      Requires: low_routes.rou.xml, medium_routes.rou.xml, high_routes.rou.xml
      Generate with: python generate_density_routes.py

    Checkpoints : every 50 episodes + on new best travel time
    Evaluation  : every 100 episodes (5 episodes, no gradient)
    """
    print("=" * 70)
    print(f"  GCN-MAPPO Training  |  device={device}  |  episodes={n_episodes}")
    print("  Reward     : -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait)")
    print("  Signal     : SUMO-native yellow timer  |  min green = 10s")
    print(f"  Episode    : {WARMUP_STEPS}s warmup + {EP_DURATION}s training = {WARMUP_STEPS+EP_DURATION}s total")
    print(f"  Curriculum : {'ON' if curriculum else 'OFF'}")
    print("=" * 70)

    ctrl      = MAPPOController(device=device)
    if resume_from:
        ctrl.load(resume_from)
    best_tt   = float("inf")
    ep_log    = []
    rollout_n = 0

    for ep in range(1, n_episodes + 1):
        # Select density for this episode (curriculum or fixed)
        ep_density = _get_density_for_episode(ep, n_episodes) if curriculum else density
        env     = SUMOEnv(use_gui=use_gui, density=ep_density)

        t0 = time.time()
        ep_rew, avg_tt, step_n, rollout_n = _run_episode(
            ctrl, env, learn=True, rollout_n=rollout_n)
        env.close()

        avg_rew = float(np.mean(list(ep_rew.values())))
        ep_log.append({"ep": ep, "avg_rew": avg_rew, "avg_tt": avg_tt,
                        "density": ep_density or "default"})

        dens_tag = f"[{ep_density or 'default':7s}]"
        print(f"  Ep {ep:4d}/{n_episodes} {dens_tag} | "
              f"reward={avg_rew:7.4f} | tt={avg_tt:6.1f}s | "
              f"steps={step_n:5d} | t={time.time()-t0:.0f}s")

        if ep % 50 == 0:
            ctrl.save(save_dir)
        if avg_tt > 0 and avg_tt < best_tt:
            best_tt = avg_tt
            ctrl.save(save_dir + "_best")
            print(f"  ★  New best travel time: {best_tt:.1f}s")
        if ep % 100 == 0:
            print(f"\n  Evaluating at episode {ep} ...")
            _evaluate(ctrl, n_reps=5, use_gui=False)
            print()

    ctrl.save(save_dir + "_final")
    _save_log(ep_log, save_dir)
    print(f"\n  Training complete. Best avg travel time: {best_tt:.1f}s")
    return ctrl


def _evaluate(ctrl: MAPPOController, n_reps: int = 5, use_gui: bool = False,
              density: str = None):
    """Run evaluation episodes with no parameter updates."""
    tt_l, r_l = [], []
    for _ in range(n_reps):
        env = SUMOEnv(use_gui=use_gui, density=density)
        ep_rew, avg_tt, _, _ = _run_episode(ctrl, env, learn=False)
        tt_l.append(avg_tt)
        r_l.append(float(np.mean(list(ep_rew.values()))))
        env.close()
    print(f"  Eval ({n_reps} reps): "
          f"travel_time = {np.mean(tt_l):.1f} ± {np.std(tt_l):.1f}s  |  "
          f"reward = {np.mean(r_l):.4f}")


def _save_log(log: list, directory: str):
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, "training_log.csv")
    with open(path, "w") as f:
        f.write("episode,avg_reward,avg_travel_time,density\n")
        for r in log:
            f.write(f"{r['ep']},{r['avg_rew']:.4f},{r['avg_tt']:.2f},{r.get('density', 'default')}\n")
    print(f"  Log saved -> {path}")


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="GCN-MAPPO Traffic Signal Training")
    p.add_argument("--episodes",    type=int,  default=MAX_EPISODES)
    p.add_argument("--device",      type=str,  default="cpu", choices=["cpu", "cuda"])
    p.add_argument("--save_dir",    type=str,  default="ckpt_mappo")
    p.add_argument("--resume",      type=str,  default=None)
    p.add_argument("--gui",         action="store_true")
    p.add_argument("--eval_only",   action="store_true")
    p.add_argument("--curriculum",  action="store_true",
                   help="Enable curriculum: low→medium→high density across episodes")
    p.add_argument("--density",     type=str,  default=None,
                   choices=["low", "medium", "high"],
                   help="Fixed density for training or evaluation")
    args = p.parse_args()

    if args.eval_only:
        ctrl = MAPPOController(device=args.device)
        if args.resume:
            ctrl.load(args.resume)
        _evaluate(ctrl, n_reps=10, use_gui=args.gui, density=args.density)
    else:
        train(n_episodes  = args.episodes,
              device       = args.device,
              save_dir     = args.save_dir,
              resume_from  = args.resume,
              use_gui      = args.gui,
              curriculum   = args.curriculum,
              density      = args.density)
