"""
networks.py
===========
Neural network building block for MA Q-Learning:
  - LinearQNetwork  single-layer (no hidden units) Q-function approximator

Kept separate from ma_qlearning.py so the model definition is easy to
find independently of the agent/controller orchestration logic.
"""

import torch
import torch.nn as nn


class LinearQNetwork(nn.Module):
    """
    Q(s, a) approximated with a SINGLE linear layer.
    Output: Q-values for all actions, shape (action_dim,).

    This is intentionally shallow to distinguish Q-learning from DQN.
    The key limitation: cannot model non-linear interactions between
    junction features — precisely what makes MAPPO and DQN outperform it.
    """
    def __init__(self, obs_dim: int, action_dim: int):
        super().__init__()
        self.fc = nn.Linear(obs_dim, action_dim)
        nn.init.zeros_(self.fc.weight)
        nn.init.zeros_(self.fc.bias)

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        return self.fc(obs)
