"""
ma_qlearning.py
===============
Multi-Agent Q-Learning with GCN encoder for Manhattan 4x4 traffic network.

KEY DESIGN DECISIONS (important for paper comparison):
──────────────────────────────────────────────────────
  • Q-function  : LINEAR approximator (1 layer, NO hidden layers)
                  This is the defining difference from DQN.
                  Shallow → fast to train, but limited representational power.
  • Updates     : ONLINE — one gradient step every simulation step.
                  No replay buffer, no target network.
  • Exploration : ε-greedy with linear decay over training.
  • GCN         : Shared MultiLayerGCN (identical to MAPPO/DQN).
                  State = raw_obs + GCN embedding (augmented obs).
  • Execution   : Fully decentralised — each junction has its own Q-network.

WHY LINEAR Q vs DQN matters in the paper:
  Q-learning (linear) = classical value-based RL, cannot capture complex
  non-linear traffic interactions → expected to under-perform DQN and MAPPO.
  DQN adds deep network + replay buffer + target network = better stability.
  MAPPO adds policy gradient + centralised critic = best multi-agent coordination.

Reward (from traci_env):
  R = -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait)  ∈ [-1, 0]
  Identical reward signal used by all three algorithms for fair comparison.

The Q-network definition (LinearQNetwork) lives in networks.py. The
training loop lives in train.py, alongside SUMOEnv in traci_env.py.
"""

import os
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim

from junction_config import REAL_JUNCTIONS, ACT_DIM, RAW_OBS_DIM
from gcn_encoder import MultiLayerGCN, get_augmented_obs_dims
from networks import LinearQNetwork

# ─────────────────────────────────────────────────────────────────────────────
#  HYPERPARAMETERS
# ─────────────────────────────────────────────────────────────────────────────

GAMMA         = 0.99      # discount factor
LR_Q          = 1e-3      # learning rate for Q-network
EPS_START     = 1.0       # initial exploration rate
EPS_END       = 0.05      # minimum exploration rate
EPS_DECAY     = 0.995     # per-episode epsilon decay
GRAD_CLIP     = 0.5       # gradient clipping
MAX_EPISODES  = 1000

AUG_OBS_DIM  = get_augmented_obs_dims()   # {jid: int}


# ─────────────────────────────────────────────────────────────────────────────
#  PER-JUNCTION Q-LEARNING AGENT
# ─────────────────────────────────────────────────────────────────────────────

class MAQLAgent:
    """
    Single-junction Q-learning agent.
    Online TD(0) update: Q(s,a) ← Q(s,a) + α[r + γ·max_a' Q(s',a') - Q(s,a)]
    """
    def __init__(self, jid: str, device: torch.device, epsilon_ref: list):
        """
        Args:
            epsilon_ref: mutable list [epsilon] shared with controller
                         so epsilon decay is centralised.
        """
        self.jid         = jid
        self.dev         = device
        self.na          = ACT_DIM[jid]
        self.epsilon_ref = epsilon_ref  # shared reference
        self.q_net       = LinearQNetwork(AUG_OBS_DIM[jid], self.na).to(device)
        self.optimizer   = optim.Adam(self.q_net.parameters(), lr=LR_Q)
        self.loss_fn     = nn.MSELoss()

        # Transition memory (previous step only — online update)
        self._prev_obs    = None
        self._prev_action = None
        self.steps        = 0
        self.total_loss   = 0.0

    @torch.no_grad()
    def act(self, aug_obs: np.ndarray) -> int:
        """ε-greedy action selection."""
        if np.random.random() < self.epsilon_ref[0]:
            return np.random.randint(0, self.na)
        obs_t = torch.FloatTensor(aug_obs).unsqueeze(0).to(self.dev)
        q_vals = self.q_net(obs_t)
        return int(q_vals.argmax(dim=1).item())

    def store(self, aug_obs: np.ndarray, action: int):
        """Store current observation and action for next-step update."""
        self._prev_obs    = aug_obs
        self._prev_action = action

    def update(self, reward: float, next_obs: np.ndarray, done: bool):
        """
        Online TD(0) update — called every simulation step.
        No replay buffer: updates immediately from (s, a, r, s').
        """
        if self._prev_obs is None:
            return 0.0

        s  = torch.FloatTensor(self._prev_obs).unsqueeze(0).to(self.dev)
        ns = torch.FloatTensor(next_obs).unsqueeze(0).to(self.dev)
        a  = torch.LongTensor([self._prev_action]).to(self.dev)
        r  = torch.FloatTensor([reward]).to(self.dev)

        # Current Q-value for the taken action
        q_current = self.q_net(s).gather(1, a.unsqueeze(1)).squeeze(1)

        # TD target: r + γ · max_a' Q(s', a')  [zero if done]
        with torch.no_grad():
            if done:
                q_target = r
            else:
                q_next   = self.q_net(ns).max(dim=1)[0]
                q_target = r + GAMMA * q_next

        loss = self.loss_fn(q_current, q_target)

        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.q_net.parameters(), GRAD_CLIP)
        self.optimizer.step()

        self.steps      += 1
        self.total_loss += loss.item()
        return loss.item()

    def save(self, path: str):
        torch.save({"q_net": self.q_net.state_dict(), "steps": self.steps}, path)

    def load(self, path: str):
        ck = torch.load(path, map_location=self.dev)
        self.q_net.load_state_dict(ck["q_net"])
        self.steps = ck.get("steps", 0)


# ─────────────────────────────────────────────────────────────────────────────
#  MA Q-LEARNING CONTROLLER
# ─────────────────────────────────────────────────────────────────────────────

class MAQLController:
    """
    Coordinates all per-junction Q-learning agents with shared GCN encoder.

    Drop-in replacement for MAPPOController — same act() / store() / update()
    interface so the training loop in train.py can be reused.

    Differences from MAPPOController:
      • No centralised critic (fully decentralised Q-values)
      • No rollout buffer — online updates every step
      • No policy distribution — epsilon-greedy discrete actions
      • Q-network is linear (1 layer) vs PPO actor (3 layers)
    """
    def __init__(self, device: str = "cpu", gcn_ckpt: str = None):
        self.dev       = torch.device(device)
        self.gcn       = MultiLayerGCN(device=device).to(self.dev)
        if gcn_ckpt and os.path.exists(gcn_ckpt):
            self.gcn.load_state_dict(torch.load(gcn_ckpt, map_location=self.dev))

        # Shared epsilon reference — all agents use same exploration rate
        self.epsilon   = [EPS_START]
        self.agents    = {jid: MAQLAgent(jid, self.dev, self.epsilon)
                          for jid in REAL_JUNCTIONS}
        self.global_step = 0
        self._aug_obs    = {}   # cached augmented obs from current step
        self._print_summary()

    def _print_summary(self):
        gcn_p = sum(p.numel() for p in self.gcn.parameters())
        q_p   = sum(p.numel() for p in self.agents["n_1_1"].q_net.parameters())
        total = gcn_p + q_p * len(self.agents)
        print(f"\n  MAQLController ready")
        print(f"  Algorithm  : Q-Learning  |  Q-network: Linear (1 layer)")
        print(f"  Junctions  : {len(self.agents)}")
        print(f"  GCN params : {gcn_p:,}   Q-net per agent: {q_p:,}   Total: {total:,}")
        print(f"  Epsilon    : {EPS_START} → {EPS_END}  (decay {EPS_DECAY}/episode)")
        print(f"  Update     : Online TD(0), no replay buffer, no target network")

    def act(self, raw_obs: dict):
        """
        Compute augmented observations via GCN, then select actions ε-greedily.
        Returns actions dict compatible with traci_env step().
        """
        self._aug_obs = self.gcn.augment_obs(raw_obs)
        actions = {}
        for jid, agent in self.agents.items():
            a = agent.act(self._aug_obs[jid])
            agent.store(self._aug_obs[jid], a)
            actions[jid] = a
        return actions

    def update(self, raw_obs: dict, rewards: dict, done: bool) -> dict:
        """
        Online update — called every simulation step with (rewards, next_obs).
        GCN encodes next observation, then each agent does one TD(0) step.
        """
        next_aug = self.gcn.augment_obs(raw_obs)
        losses   = []
        for jid, agent in self.agents.items():
            r    = rewards.get(jid, 0.0)
            loss = agent.update(r, next_aug[jid], done)
            losses.append(loss)
        self.global_step += 1
        return {"q_loss": float(np.mean(losses)), "epsilon": self.epsilon[0]}

    def decay_epsilon(self):
        """Call once per episode after the episode ends."""
        self.epsilon[0] = max(EPS_END, self.epsilon[0] * EPS_DECAY)

    def save(self, directory: str = "ckpt_qlearning"):
        os.makedirs(directory, exist_ok=True)
        torch.save(self.gcn.state_dict(), os.path.join(directory, "gcn.pt"))
        for jid, agent in self.agents.items():
            agent.save(os.path.join(directory, f"qnet_{jid}.pt"))
        print(f"  Saved -> {directory}/")

    def load(self, directory: str = "ckpt_qlearning"):
        p = os.path.join(directory, "gcn.pt")
        if os.path.exists(p):
            self.gcn.load_state_dict(torch.load(p, map_location=self.dev))
        for jid, agent in self.agents.items():
            p = os.path.join(directory, f"qnet_{jid}.pt")
            if os.path.exists(p):
                agent.load(p)
        print(f"  Loaded <- {directory}/")
